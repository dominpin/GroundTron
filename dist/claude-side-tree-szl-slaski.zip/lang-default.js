globalThis.CST_DEFAULT_LANG = 'szl';
