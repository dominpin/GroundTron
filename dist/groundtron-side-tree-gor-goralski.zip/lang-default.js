globalThis.CST_DEFAULT_LANG = 'gor';
